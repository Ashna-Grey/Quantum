# PauliGuard Orange / Off-White Frontend

This frontend replaces the dark dashboard with an off-white/orange interactive dashboard.

## Backend compatibility

Uses the existing backend endpoints:

- `GET /health`
- `POST /api/qds/demo`
- `POST /api/run`
- `GET /api/formula/{n}`

## Deployment

Replace `static/index.html` in the existing PauliGuard repository, commit and push. Render will redeploy the same service.

The browser stores only a small local history of experiment results in `localStorage` for the dashboard charts. No server-side schema change is required.
